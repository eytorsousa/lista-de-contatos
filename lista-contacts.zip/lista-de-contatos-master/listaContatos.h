typedef struct cliente{
    int cod;
    char nome[60];
    char empresa[80];
    char depart[80];
    char telefone[15];
    char celular[16];
    char email[60];
} CLIENTE;

typedef struct elemento* Lista;

//Fun��o para criar a nossa lista sequencial dinamica
Lista *criaLista();

//Fun��o para validar se a lista esta cheia
int listaCheia(Lista *li);

//Fun��o para validar se a lista est� vazia
int listaVazia(Lista *li);

//Fun��o para nos informar o tamanho da lista
int tamanhoLista(Lista *li);

//Fun��o que funciona mais ou menos como um apanhado de fun��es para serem requisitadas atrav�s do menu
void coletaDados(int escolha, Lista *li);

//Fun��o que utiliza da inser��o ordenada para inserir uma estrutura na lista
void insereCliente(Lista *li);
int insere_lista_ordenada(Lista *li, CLIENTE cl);

//Fun��o capaz de formatar o input passado, limpando o buffer, suprimindo o \n da string e colocando em formato upper em alguns casos
void formatInputChar(int tamanho, bool x, void *input);

//Fun��o para consultar a lista atrav�s do codigo informado
void consultaClienteCodigo(Lista *li);
int consulta_lista_cod(Lista *li, int cod, CLIENTE *cl);

//Fun��o para consultar a lista atrav�s do nome informado
void consulta_lista_nome(Lista *li);

//Fun��o para consultar todas as estruturas presentes na lista
void consulta_lista(Lista *li);

//Fun��es capazes de editar e remover a estrutura CLIENTE da lista. A edi��o � basicamente uma remo��o e depois uma inser��o com o cliente mantendo o codigo
void editaClienteCodigo(Lista *li);
void removeClienteCodigo(Lista *li);

//Liberando a lista
void libera_lista(Lista *li);

//Fun��es para carregamento e salvamento de dados do arquivo "contats.bin"
void carregaDadosDoArquivo(Lista *li, char contatos[]);
void salvaDadosNoArquivo(Lista *li, char contatos[]);
int remove_lista(Lista *li, int cod);
