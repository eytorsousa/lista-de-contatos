#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "listaContatos.h"

struct elemento{
    CLIENTE dados;
    struct elemento *prox;
};

typedef struct elemento ELEMENTO;

Lista *criaLista(){
    Lista *li;
    li = (Lista*) malloc(sizeof(Lista));
    if(li != NULL){
        *li = NULL;
    }
    return li;
}

int listaCheia(Lista *li){
    return 0;
}

int listaVazia(Lista *li){
    if(li == NULL){
        return 1;
    }
    if(*li == NULL){
        return 1;
    }
    return 0;
}

int tamanhoLista(Lista *li) {
    if(li == NULL){
        return -1;
    }

    int acum = 0;
    ELEMENTO *no = *li;
    while(no != NULL){
        acum++;
        no = no->prox;
    }
    return acum;
}


/* ----------------------------------------------------------- */
/* Switch principal: gerencia a chamada de funcoes auxiliares que, por sua vez, chamam as funcoes de execucao */
void coletaDados(int escolha, Lista *li){

    switch(escolha){
        case 1:
            system("cls");
            insereCliente(li);
            break;
        case 2:
            system("cls");
            consultaClienteCodigo(li);
            break;
        case 3:
            system("cls");
            consulta_lista_nome(li);
            break;
        case 4:
            system("cls");
            consulta_lista(li);
            break;
        case 5:
            system("cls");
            editaClienteCodigo(li);
            break;
        case 6:
            system("cls");
            removeClienteCodigo(li);
            break;
    }


}
/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao void auxiliar: coleta informacoes e insere na lista dinamica de forma ordenada */
void insereCliente(Lista *li){
    CLIENTE cl;
    int x;

    printf("\n[-------------------- INSERINDO CLIENTE --------------------]\n\n");

    printf("Insira o CODIGO do cliente: ");
    scanf(" %d", &cl.cod);
    printf("\nInsira o NOME do cliente: ");
    formatInputChar(60, true, cl.nome);
    printf("\nInsira o NOME da EMPRESA: ");
    formatInputChar(80, true, cl.empresa);
    printf("\nInsira o NOME do DEPARTAMENTO: ");
    formatInputChar(80, true, cl.depart);
    printf("\nInsira o numero de TELEFONE com DDD (ex.: 1124044240)\nTELEFONE: ");
    formatInputChar(15, false, cl.telefone);
    printf("\nInsira o numero de CELULAR com DDD (ex.: 11912345678)\nCELULAR: ");
    formatInputChar(16, false, cl.celular);
    printf("\nInsira o E-MAIL do cliente: ");
    formatInputChar(60, false, cl.email);

    x = insere_lista_ordenada(li, cl);
    system("cls");
    if(x){
        printf("\n\tCLIENTE INSERIDO COM SUCESSO!\n");
    } else {
        printf("\n\tFALHA AO INSERIR CLIENTE!\n");
    }

    printf("\n\tAPERTE QUALQUER TECLA PARA VOLTAR AO MENU INICIAL\n\n");
    system("pause");
    system("cls");
}

/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao void auxiliar: limpa buffers, coleta variaveis do tipo char e converte em uppercase se for necessario */
void formatInputChar(int tamanho, bool x, void *input){

    // Limpar o buffer de entrada
    fflush(stdin);
    // Lendo uma variavel do tipo char/string
    fgets((char*)input, tamanho-1, stdin);
    // Removendo o ultimo caractere da string lida (\n)
    size_t length = strlen((char*)input);
    if (length > 0 && ((char*)input)[length - 1] == '\n') {
        ((char*)input)[length - 1] = '\0';
    }
    // Limpando o buffer novamente por seguranca
    fflush(stdin);

    // Se x for true, a string e convertida em maiuscula
    if(x){
        strupr((char*)input);
    }
}
/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao int: aplica a operacao desejada (insercao ordenada) */
int insere_lista_ordenada(Lista *li, CLIENTE cl){
    if(li == NULL){
        return 0;
    }
    ELEMENTO *no = (ELEMENTO*) malloc(sizeof(ELEMENTO));
    if(no == NULL){
        return 0;
    }
    no->dados = cl;
    if(listaVazia(li)){
        no->prox = (*li);
        *li = no;
        return 1;
    } else {
        ELEMENTO *ant, *atual = *li;
        while(atual != NULL && atual->dados.cod < cl.cod){
            ant = atual;
            atual = atual->prox;
        }
        if(atual == *li){
            no->prox = (*li);
            *li = no;
        } else {
            no->prox = ant->prox;
            ant->prox = no;
        }

        return 1;
    }
}
/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao void : coleta informacoes e realiza a operacao (consulta por codigo) */
void consultaClienteCodigo(Lista *li) {
    int cod;

    printf("\n[-------------------- CONSULTANDO CLIENTE (CODIGO) --------------------]\n");
    printf("\nInsira o CODIGO do cliente que deseja buscar: ");
    scanf(" %d", &cod);

    ELEMENTO *atual = *li;
    while (atual != NULL) {
        CLIENTE cl = atual->dados;
        if (cl.cod == cod) {
            printf("\n[-------------------- CONSULTANDO CLIENTE (CODIGO) --------------------]\n");
            printf("\nINFORMACOES DO CLIENTE DE CODIGO %d:", cod);
            printf("\n\nNome: \t\t\t%s", cl.nome);
            printf("\nEmpresa: \t\t%s", cl.empresa);
            printf("\nDepartamento: \t\t%s", cl.depart);
            printf("\nTelefone: \t\t%s", cl.telefone);
            printf("\nCelular: \t\t%s", cl.celular);
            printf("\nE-mail: \t\t%s", cl.email);
            printf("\n\n[-------------------------------------------------------------------------]\n");

            printf("\n\tAPERTE QUALQUER TECLA PARA VOLTAR AO MENU INICIAL\n\n");
            system("pause");
            system("cls");

            return; // Sai da fun��o ap�s encontrar o cliente
        }
        atual = atual->prox;
    }

    // Se o c�digo n�o for encontrado
    printf("\n\tCliente %d nao encontrado na lista!\n", cod);

    printf("\n\tAPERTE QUALQUER TECLA PARA VOLTAR AO MENU INICIAL\n\n");
    system("pause");
    system("cls");
}
/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao void principal: coleta informacoes e realiza a operacao (consulta por nome) */
void consulta_lista_nome(Lista *li) {
    char nome[60];
    CLIENTE cl;

    printf("\n[-------------------- CONSULTANDO CLIENTE (NOME) --------------------]");
    printf("\nInsira o NOME do cliente que deseja buscar: ");
    formatInputChar(60, true, nome);
    system("cls");

    int found = 0; //Utilizando uma variavel como especie de condicional, caso ela seja alterada para 1 = true, significa que o usuario com certo nome foi encontrado
    ELEMENTO *atual = *li;

    while (atual != NULL) {
        cl = atual->dados;
        if (strstr(cl.nome, nome) != NULL) { //Estamos utilizando o strstr para pegar a substring de uma string, sendo a substring o nome passado, consequentemnte mostrando as pessoas que tem nomes iguais ou parcialmente iguais
            found = 1;
            printf("\n[-------------------- CONSULTANDO CLIENTE (NOME) --------------------]\n");
            printf("\nINFORMACOES DO CLIENTE DE CODIGO %d:", cl.cod);
            printf("\n\nNome: \t\t\t%s", cl.nome);
            printf("\nEmpresa: \t\t%s", cl.empresa);
            printf("\nDepartamento: \t\t%s", cl.depart);
            printf("\nTelefone: \t\t%s", cl.telefone);
            printf("\nCelular: \t\t%s", cl.celular);
            printf("\nE-mail: \t\t%s", cl.email);
            printf("\n\n[-------------------------------------------------------------------------]\n");


        }
        atual = atual->prox;
    }

    if (!found) {
        printf("\n\tCliente %s nao encontrado na lista!\n", nome);
    }

    printf("\n\tAPERTE QUALQUER TECLA PARA VOLTAR AO MENU INICIAL\n\n");
    system("pause");
    system("cls");
}
/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao void: Percorre todas as estruturas existentes e as exibe na tela (consulta total) */
void consulta_lista(Lista *li) {
    // Consulta na lista em mem�ria
    if (!listaVazia(li)) {
        ELEMENTO *atual = *li;

        printf("\n[-------------------- CONSULTANDO CLIENTES NA LISTA --------------------]\n");

        while (atual != NULL) {
            CLIENTE cl = atual->dados;
            // Imprimir os dados conforme necess�rio
            printf("\nINFORMACOES DO CLIENTE DE CODIGO %d:", cl.cod);
            printf("\n\nNome: \t\t\t%s", cl.nome);
            printf("\nEmpresa: \t\t%s", cl.empresa);
            printf("\nDepartamento: \t\t%s", cl.depart);
            printf("\nTelefone: \t\t%s", cl.telefone);
            printf("\nCelular: \t\t%s", cl.celular);
            printf("\nE-mail: \t\t%s", cl.email);
            printf("\n\n[-------------------------------------------------------------------------]\n");

            atual = atual->prox;
        }
    } else {
        printf("\n\tA LISTA ESTA VAZIA!\n");
    }

    printf("\n\tAPERTE QUALQUER TECLA PARA VOLTAR AO MENU INICIAL\n\n");
    system("pause");
    system("cls");
}



/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao void: coleta informacoes e realiza a operacao (edicao de cliente) */
void editaClienteCodigo(Lista *li) {
    int cod, x;
    CLIENTE cl;
    ELEMENTO *atual = *li;

    printf("\n[-------------------- EDITANDO CLIENTE (CODIGO) --------------------]\n");
    printf("\nInsira o CODIGO do cliente que deseja editar: ");
    scanf(" %d", &cod);
    system("cls");

    int found = 0;

    while (atual != NULL) {
        cl = atual->dados;
        if (cl.cod == cod) {
            printf("\nINFORMACOES DO CLIENTE DE CODIGO %d (a ser editado):", cod);
            printf("\n\nNome: \t\t\t%s", cl.nome);
            printf("\nEmpresa: \t\t%s", cl.empresa);
            printf("\nDepartamento: \t\t%s", cl.depart);
            printf("\nTelefone: \t\t%s", cl.telefone);
            printf("\nCelular: \t\t%s", cl.celular);
            printf("\nE-mail: \t\t%s", cl.email);
            printf("\n\n[-------------------------------------------------------------------------]\n");

            x = -1;

            do {
                printf("\nTem certeza que deseja EDITAR o cliente acima?");
                printf("\n\tSIM[1] // NAO[0]\n");
                printf("\nEscolha: ");
                scanf(" %d", &x);
                if (x < 0 || x > 1) {
                    do {
                        printf("\n\tESCOLHA INVALIDA! INSIRA NOVAMENTE!");
                        printf("\nInsira o numero da operacao: ");
                        scanf(" %d", &x);
                    } while (x < 0 || x > 1);
                }
                system("cls");
            } while (x < 0 || x > 1);

            if (x == 1) {
                // Remove o cliente atual
                remove_lista(li, cod);

                // Pede as novas informa��es do cliente
                printf("\n[-------------------- EDITANDO CLIENTE --------------------]\n\n");
                printf("\nInsira o NOVO NOME do cliente: ");
                formatInputChar(60, true, cl.nome);
                printf("\nInsira o NOVO NOME da EMPRESA: ");
                formatInputChar(80, true, cl.empresa);
                printf("\nInsira o NOVO NOME do DEPARTAMENTO: ");
                formatInputChar(80, true, cl.depart);
                printf("\nInsira o NOVO numero de TELEFONE com DDD (ex.: 1124044240)\nTELEFONE: ");
                formatInputChar(15, false, cl.telefone);
                printf("\nInsira o NOVO numero de CELULAR com DDD (ex.: 11912345678)\nCELULAR: ");
                formatInputChar(16, false, cl.celular);
                printf("\nInsira o NOVO E-MAIL do cliente: ");
                formatInputChar(60, false, cl.email);

                // Insere o cliente atualizado
                insere_lista_ordenada(li, cl);
                system("cls");

                printf("\n\tCLIENTE EDITADO COM SUCESSO!\n");
            }
            found = 1;
            break; // Sai do loop ap�s editar o cliente
        }
        atual = atual->prox;
    }

    if (!found) {
        printf("\n\tCLIENTE %d NAO ENCONTRADO!\n", cod);
    }

    printf("\n\tAPERTE QUALQUER TECLA PARA VOLTAR AO MENU INICIAL\n\n");
    system("pause");
    system("cls");
}

/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao void: coleta informacoes e realiza a operacao (remocao de cliente) */
void removeClienteCodigo(Lista *li){
    int cod, x;
    CLIENTE cl;

    printf("\nInsira o CODIGO do cliente que deseja remover: ");
    scanf(" %d", &cod);
    system("cls");

    x = consulta_lista_cod(li, cod, &cl); //Fazemos a consulta com base no c�digo informado
    if(x){
        printf("\n[-------------------- REMOVENDO CLIENTE (CODIGO) --------------------]\n");
        printf("\nINFORMACOES DO CLIENTE DE CODIGO %d:", cod);
        printf("\n\nNome: \t\t\t%s", cl.nome);
        printf("\nEmpresa: \t\t%s", cl.empresa);
        printf("\nDepartamento: \t\t%s", cl.depart);
        printf("\nTelefone: \t\t%s", cl.telefone);
        printf("\nCelular: \t\t%s", cl.celular);
        printf("\nE-mail: \t\t%s", cl.email);
        printf("\n\n[-------------------------------------------------------------------------]\n");
    } else {
        printf("\n\tCliente %d nao encontrado!\n", cod);
    }

    if(x){ //Nesse trecho de c�digo montamos uma mensagem de alerta, a qual solicita confirma��o do usu�rio para apagar o cliente Sim(1) e N�o(2)
        x = -1;
        do{
            printf("\nTem certeza que deseja REMOVER o cliente acima?");
            printf("\n\tSIM[1] // NAO[0]\n");
            printf("\nEscolha: ");
            scanf(" %d", &x);
            if(x < 0 || x > 1){
                do{
                    printf("\n\tESCOLHA INVALIDA! INSIRA NOVAMENTE!");
                    printf("\nInsira o numero da operacao: ");
                    scanf(" %d", &x);
                } while(x < 0 || x > 1);
            }
            system("cls");
        } while(x < 0 || x > 1);
    }

    if(x){
        x = remove_lista(li, cod);
    }

    if(x){
        printf("\n\tCLIENTE REMOVIDO COM SUCESSO!\n");
    } else {
        printf("\n\tFALHA AO REMOVER CLIENTE!\n\n\tOPERACAO CANCELADA!");
    }
}

int remove_lista(Lista *li, int cod){
    if(li == NULL){
        return 0;
    }
    ELEMENTO *ant, *no = *li;
    while(no != NULL && no->dados.cod != cod){
        ant = no;
        no = no->prox;
    }

    if(no == NULL){
        return 0;
    }

    if(no == *li){
        *li = no->prox;
    } else {
        ant->prox = no->prox;
    }

    free(no);
    return 1;
}

void libera_lista(Lista *li){
    if(li != NULL){
        ELEMENTO *atual;
        while((*li)!= NULL){
            atual = *li;
            *li = (*li)->prox;
            free(atual);

        }
        free(li);
    }
}

/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao void: carrega os dados do arquivo com o fread e insere na lista de forma ordenada */

void carregaDadosDoArquivo(Lista *li, char contatos[]) {
    FILE *f = fopen(contatos, "rb");
    if (f == NULL) {
        printf("\n\tErro ao abrir o arquivo para leitura!\n");
        return;
    }

    CLIENTE cl;

    while (fread(&cl, sizeof(CLIENTE), 1, f)) {
        // Adiciona � lista din�mica de forma ordenda
        insere_lista_ordenada(li, cl);
    }

    fclose(f);
}


/* ----------------------------------------------------------- */

/* ----------------------------------------------------------- */
/* Funcao void: Salva/Escreve os dados das estruturas  dos clientes presentes na lista no arquivo bin�rio */
void salvaDadosNoArquivo(Lista *li, char contatos[]) {
    FILE *f = fopen(contatos, "wb");
    if (f == NULL) {
        printf("\n\tErro ao abrir o arquivo para escrita!\n");
        return;
    }

    ELEMENTO *atual = *li;

    while (atual != NULL) {
        CLIENTE cliList = atual->dados;
        fwrite(&cliList, sizeof(CLIENTE), 1, f);
        atual = atual->prox;
    }

    fclose(f);
}

int consulta_lista_cod(Lista *li, int cod, CLIENTE *cl){
    if(li == NULL){
        return 0;
    }
    ELEMENTO *no = *li;
    while(no != NULL && no->dados.cod != cod){
        no = no->prox;
    }
    if(no == NULL){
        return 0;
    } else {
        *cl = no->dados;
        return 1;
    }
}

/* ----------------------------------------------------------- */
