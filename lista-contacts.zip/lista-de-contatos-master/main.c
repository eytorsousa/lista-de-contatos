#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "listaContatos.h"

int main(){
    Lista *li;
    li = criaLista();
    int escolha;

    carregaDadosDoArquivo(li, "contats.bin"); //Criamos uma funcao para buscar pelas estruturas no arquivo e joga-las numa lista dinamica

    //Menu de utilizacao para cada uma das funcoes solicitadas
    do{
        printf("\n[-------------------- MENU --------------------]\n\n");
        printf("[1] - Inserir novo cliente\n\n");
        printf("[2] - Buscar cliente por CODIGO\n\n");
        printf("[3] - Buscar cliente por NOME\n\n");
        printf("[4] - Gerar relatorio - Lista Completa\n\n");
        printf("[5] - Editar cliente\n\n");
        printf("[6] - Remover cliente\n\n");
        printf("[0] - ENCERRAR PROGRAMA");
        printf("\n\n[----------------------------------------------]\n\n");
        printf("Insira o numero da operacao: ");
        scanf(" %d", &escolha);

        if(escolha < 0 || escolha > 6){
            do{
                printf("\n\tESCOLHA INVALIDA! INSIRA NOVAMENTE!");
                printf("\nInsira o numero da operacao: ");
                scanf(" %d", &escolha);
            } while(escolha < 0 || escolha > 6);
        }
        if(escolha > 0 && escolha < 7){
            coletaDados(escolha, li);
        }
    } while(escolha != 0);

    //Ap�s o programa cair na op��o de finaliza��o, chamamos a fun��o para salvar todas as estruturas da lista no arquivo binario

    salvaDadosNoArquivo(li, "contats.bin");

    //Liberamos a lista
    libera_lista(li);
    printf("\n\n\tFIM DO PROGRAMA!\n");
    system("pause");
    return 0;
}
